package org.zerock.controller;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.ModelMap;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.zerock.domain.BoardVO;
import org.zerock.mapper.BoardMapperTests;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)

//웹브라우저
@WebAppConfiguration
//이 경로 파일 들고오기
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/root-context.xml",
		"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
@Log4j

public class BoardControllerTests {


	@Autowired
	private WebApplicationContext ctx;
	
	//가짜 mvc
	private MockMvc mockMvc;
	
	//context 올리기
	@Before
	public void setup() {
		
		/* this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build(); */
		
		
		  DefaultMockMvcBuilder a = MockMvcBuilders.webAppContextSetup(ctx); 
		  MockMvc b = a.build();
		  this.mockMvc = b;
		 		
	}
	
	
	//리스트 테스트
	@Test
	public void testList() throws Exception {
		
		/*
		 * log.info( mockMvc.perform(MockMvcRequestBuilders.get("/board/list"))
		 * .andReturn() .getModelAndView() .getModelMap() );
		 */
		
		
		 MockHttpServletRequestBuilder a = MockMvcRequestBuilders.get("/board/list");
		 ResultActions b = mockMvc.perform(a);
		  MvcResult c  = b.andReturn();
		  ModelAndView d = c.getModelAndView();
		  ModelMap e = d.getModelMap();
		  
		  List<BoardVO> f = (List<BoardVO>) e.get("list");
             
		  for(int index=0; index < f.size(); index++) {
			 BoardVO vo = f.get(index);
		  log.info(vo);
		  
		}	 
	}   
	
	
	//등록 테스트
	
	@Test
	public void testRegister() throws Exception{
		
		/*
		 * String resultPage = mockMvc.perform(MockMvcRequestBuilders.post(
		 * "/board/register") .param("title", "테스트 새글 제목") .param("content",
		 * "테스트 새글 내용") .param("writer", "user00")
		 * ).andReturn().getModelAndView().getViewName();
		 * 
		 * log.info(resultPage);
		 */
		  	  
		 MockHttpServletRequestBuilder a = MockMvcRequestBuilders.post("/board/register");
				 
		a.param("title", "테스트 새글 제목");
		a.param("content", "테스트 새글 내용");
		a.param("writer", "user00");  
		  
		ResultActions b = mockMvc.perform(a);  
		MvcResult c = b.andReturn();
		ModelAndView d = c.getModelAndView();
		
		String e = d.getViewName();
		
		log.info("#######: " + e);
		  
	}
	
	
	//조회 테스트
	@Test
	public void testGet() throws Exception {
		
		/*log.info(mockMvc.perform(MockMvcRequestBuilders
		.get("/board/get")		
		.param("bno", "1"))
		.andReturn()
		.getModelAndView().getModelMap());*/
	
		MockHttpServletRequestBuilder a = MockMvcRequestBuilders.get("/board/get");
		
		a.param("bno", "1");
	
		ResultActions b = mockMvc.perform(a);
		MvcResult c = b.andReturn();
		ModelAndView d =c.getModelAndView();
		
		ModelMap e = d.getModelMap();
		
		log.info("######" + e);

	}
	
	//수정 테스트
	@Test
	public void testModify() throws Exception{
		
		
		/*String resultPage = mockMvc.perform(MockMvcRequestBuilders.post(
				"/board/modify")
				.param("bno", "1")
				.param("title", "수정된 테스트 새글 제목")
				.param("content", "수정된 테스트 새글 내용")
				.param("writer", "user00")
				).andReturn().getModelAndView().getViewName();
	                
		  log.info(resultPage);*/
		  
		  MockHttpServletRequestBuilder a = MockMvcRequestBuilders.post("/board/modify");
		  
		  a.param("bno", "1");
		  a.param("title","수정된 테스트 새글 제목");
		  a.param("content", "수정된 테스트 새글 내용");
		  a.param("writer", "user00");
		  
		  ResultActions b = mockMvc.perform(a);  
			MvcResult c = b.andReturn();
			ModelAndView d = c.getModelAndView();
			String e = d.getViewName();
			
			log.info("#######: " + e);
		  
	}
	
	
	//삭제 테스트
	@Test
	public void testRemove() throws Exception{
		
		//삭제 전 데이터베이스에 게시물 번호 확인 할 것
		/*String resultPage = mockMvc.perform(MockMvcRequestBuilders.post(
				"/board/remove")
				.param("bno", "42")
				).andReturn().getModelAndView().getViewName();
	                
		  log.info(resultPage);*/
		
		MockHttpServletRequestBuilder a = MockMvcRequestBuilders.post("/board/remove");
		
		a.param("bno", "1");
	    
		ResultActions b = mockMvc.perform(a);
		MvcResult c = b.andReturn();
		ModelAndView d = c.getModelAndView();
		String e = d.getViewName();
		
		log.info("#####" + e);
		
	}
	
	//페이징 테스트
	
	@Test
	public void testListPaging() throws Exception {
		
	 MockHttpServletRequestBuilder a = MockMvcRequestBuilders.get("/board/list");
			 
			 a.param("pageNum", "2");
			 a.param("amount", "50");
		
			 ResultActions b = mockMvc.perform(a);
			 MvcResult c = b.andReturn();
			 ModelAndView d = c.getModelAndView();
			 ModelMap e = d.getModelMap();
			 
			 log.info("######" + e);
		
	}
	
	
	
	
	
}



