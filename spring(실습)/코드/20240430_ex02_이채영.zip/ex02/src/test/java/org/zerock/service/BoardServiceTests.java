package org.zerock.service;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.properties.DataSourceTests;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j

public class BoardServiceTests {

	
	@Autowired
	private BoardService service;
	
	
	//객체가 제대로 주입 가능한지 확인하는 작업 테스트
	@Test
	public void testExist() {
	
	log.info(service);
	assertNotNull(service);
	}
	
	//등록 작업 테스트
	
	@Test
	public void testRegister() {
	BoardVO board = new BoardVO();
	board.setTitle("새로 작성하는 글");
	board.setContent("새로 작성하는 내용");
	board.setWriter("newbie");
    
	service.register(board);
	
	log.info("생성된 게시물의 번호: " + board.getBno());
	}
	
	//목록(리스트) 작업 테스트
	
	@Test
	public void testGetList() {
		
		//람다식
		// service.getList().forEach(board -> log.info(board)); 
		
		/*
		 * List<BoardVO> a = service.getList();
		 * 
		 * 값을 하나 가지고 올 때 인덱스를 이용해 get()을 사용함
		 * BoardVO b = a.get(0); BoardVO b1 = a.get(1); BoardVO b2 = a.get(2); BoardVO
		 * b3 = a.get(3); BoardVO b4 = a.get(4);
		 * 
		 * for(int index=0; index < a.size(); index++) {
		 * 
		 * log.info(a.get(index)); }
		 */
		
		
		//페이징 테스트 코드
		service.getList(new Criteria(2,10)).forEach(board -> log.info(board));
		
		
	}
	
	//조회 작업 테스트
	
	@Test
	public void testGet() {
		
		log.info(service.get(1L));
	}
	
	//삭제/수정 작업 테스트
	
	@Test
	public void testDelete() {
		
		//게시물 번호의 존재 여부를 확인하고 테스트 할 것
		log.info("REMOVE RESULT: " + service.remove(2L));
		
	}
	
	@Test
	public void testUpdate() {
		
		BoardVO board = service.get(1L);
		
		if(board == null) {
			return;
		}
		
		board.setTitle("제목을 수정합니다");
	    log.info("MODIFY RESULT: " + service.modify(board));
	}
	
	
	
	
	
}
