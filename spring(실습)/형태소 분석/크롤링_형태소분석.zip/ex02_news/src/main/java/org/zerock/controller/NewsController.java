package org.zerock.controller;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/news/*")
public class NewsController {

    public static String contentText;

	@GetMapping("/naver")
    public void naver(Model model) throws IOException {

        String address = "https://n.news.naver.com/mnews/article/032/0003295033";
        Document doc = Jsoup.connect(address).timeout(5000).get();

        // 타이틀 영역의 텍스트 추출
       /* Elements titleElements = doc.select("#title_area");
        String titleText = titleElements.text();
        log.info("Title: " + titleText);*/

        // 본문 영역의 텍스트 추출
        Elements contentElements = doc.select("#dic_area");
        String contentText = contentElements.text();
        log.info("Content: " + contentText);

        // 태그를 제외한 텍스트를 모델에 추가하여 뷰로 전달
       // model.addAttribute("title", titleText);
        model.addAttribute("content", contentText);
        
        
    }
}
